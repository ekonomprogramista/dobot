﻿using dobotTest.CPlusDll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dobotTest.CPlusDll
{
    class Dobot
    {
        private string port;
        private int baudRate;
        private bool isConnected = false;
        private Pose pose = new Pose();

        public Dobot(string port, int baudRate)
        {
            this.port = port;
            this.baudRate = baudRate;
        }

        public bool Connect()
        {
            StringBuilder fwType = new StringBuilder(60);
            StringBuilder version = new StringBuilder(60);

            int ret = DobotDll.ConnectDobot(port, baudRate, fwType, version);
            if (ret != (int)DobotConnect.DobotConnect_NoError)
            {
                Console.WriteLine($"Błąd połączenia: {ret}");
                return false;
            }

            isConnected = true;
            DobotDll.SetCmdTimeout(3000);
            DobotDll.SetDeviceName("Dobot Magician");
            DobotDll.SetQueuedCmdClear();
            DobotDll.SetQueuedCmdStartExec();

            Console.WriteLine("Połączono z Dobotem");
            return true;
        }

        public void Disconnect()
        {
            if (isConnected)
            {
                DobotDll.DisconnectDobot();
                isConnected = false;
            }
        }

        public void SetParams()
        {
            UInt64 cmdIndex = 0;

            JOGJointParams jsParam;
            jsParam.velocity = new float[] { 200, 200, 200, 200 };
            jsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetJOGJointParams(ref jsParam, false, ref cmdIndex);

            PTPJointParams pbsParam;
            pbsParam.velocity = new float[] { 200, 200, 200, 200 };
            pbsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetPTPJointParams(ref pbsParam, false, ref cmdIndex);

            PTPCoordinateParams cpbsParam;
            cpbsParam.xyzVelocity = 100;
            cpbsParam.xyzAcceleration = 100;
            cpbsParam.rVelocity = 100;
            cpbsParam.rAcceleration = 100;
            DobotDll.SetPTPCoordinateParams(ref cpbsParam, false, ref cmdIndex);

            PTPJumpParams pjp;
            pjp.jumpHeight = 20;
            pjp.zLimit = 100;
            DobotDll.SetPTPJumpParams(ref pjp, false, ref cmdIndex);

            PTPCommonParams pbdParam;
            pbdParam.velocityRatio = 30;
            pbdParam.accelerationRatio = 30;
            DobotDll.SetPTPCommonParams(ref pbdParam, false, ref cmdIndex);
        }

        public void AlarmTest()
        {
            int ret;
            byte[] alarmsState = new byte[32];
            UInt32 len = 32;
            ret = DobotDll.GetAlarmsState(alarmsState, ref len, alarmsState.Length);

            for (int i = 0; i < alarmsState.Length; i++)
            {
                byte alarm = alarmsState[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((alarm & 0x01 << j) > 0)
                    {
                        int alarmIndex = i * 8 + j;
                        Console.WriteLine($"Alarm: {alarmIndex}");
                    }
                }
            }
        }

        public void ClearAlarms()
        {
            if (!isConnected) return;
            DobotDll.ClearAllAlarmsState();
        }

        public Pose GetPose()
        {
            if (isConnected)
            {
                DobotDll.GetPose(ref pose);
            }
            return pose;
        }

        public UInt64 PTP(byte style, float x, float y, float z, float r)
        {
            PTPCmd pdbCmd;
            UInt64 cmdIndex = 0;

            pdbCmd.ptpMode = style;
            pdbCmd.x = x;
            pdbCmd.y = y;
            pdbCmd.z = z;
            pdbCmd.rHead = r;

            while (true)
            {
                int ret = DobotDll.SetPTPCmd(ref pdbCmd, true, ref cmdIndex);
                if (ret == 0) break;
            }
            return cmdIndex;
        }

        public void SetSuctionCup(bool enable)
        {
            if (!isConnected) return;
            UInt64 cmdIndex = 0;
            DobotDll.SetEndEffectorSuctionCup(true, enable, false, ref cmdIndex);
            Console.WriteLine("Suction: " + (enable ? "ON" : "OFF"));
        }
        public void SetGripper(bool enable)
        {
            if (!isConnected) return;
            UInt64 cmdIndex = 0;
            DobotDll.SetEndEffectorGripper(true, enable, false, ref cmdIndex);
            Console.WriteLine("Gripper: " + (enable ? "ON" : "OFF"));
        }
        public void SetJogSpeed(float velocityRatio, float accelerationRatio = 100)
        {
            if (!isConnected) return;
            UInt64 cmdIndex = 0;
            JOGCommonParams jdParam;
            jdParam.velocityRatio = velocityRatio;
            jdParam.accelerationRatio = accelerationRatio;
            DobotDll.SetJOGCommonParams(ref jdParam, false, ref cmdIndex);
            Console.WriteLine($"Jog speed -> V:{velocityRatio}% A:{accelerationRatio}%");
        }
        public void SetPTPSpeed(float velocityRatio, float accelerationRatio)
        {
            if (!isConnected) return;
            UInt64 cmdIndex = 0;
            PTPCommonParams pbdParam;
            pbdParam.velocityRatio = velocityRatio;
            pbdParam.accelerationRatio = accelerationRatio;
            DobotDll.SetPTPCommonParams(ref pbdParam, false, ref cmdIndex);
            Console.WriteLine($"PTP speed -> V:{velocityRatio}% A:{accelerationRatio}%");
        }
    }
}
